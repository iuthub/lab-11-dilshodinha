

function Textresize(){
	document.getElementById("area").style.fontSize= '24px';
}



function make(){
	if (document.getElementById('bling').checked)
	{
		document.getElementById('area').style.fontStyle='italic';
		document.getElementById('area').style.color='green';
		document.getElementById('area').style.textDecoration='underline';
	}
	else
	{
		document.getElementById('area').style.fontStyle='normal';
	}
}